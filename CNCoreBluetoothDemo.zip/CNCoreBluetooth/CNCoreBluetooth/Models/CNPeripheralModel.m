//
//  CNPeripheralModel.m
//  CNCoreBluetooth
//
//  Created by apple on 2018/1/30.
//  Copyright © 2018年 apple. All rights reserved.
//

#import "CNPeripheralModel.h"

@implementation CNPeripheralModel

@end
