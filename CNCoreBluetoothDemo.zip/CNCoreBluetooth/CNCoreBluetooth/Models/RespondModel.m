//
//  RespondModel.m
//  CNCoreBluetooth
//
//  Created by apple on 2018/2/4.
//  Copyright © 2018年 apple. All rights reserved.
//

#import "RespondModel.h"

@implementation RespondModel

@end
